# teaData
This is the tea dataset, where the training set, validation set and test set contain 5368, 665 and 665 triples respectively.
